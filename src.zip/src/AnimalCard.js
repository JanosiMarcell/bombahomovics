import React from 'react';
import './AnimalCard.css';

function AnimalCard({ number, name, image, description, bgcolor }) {
  return (
    <div className="animal-card" style={{background:bgcolor}}>
      <img src={image} alt={name} className="animal-image" />
      <div className="animal-info">
        <h2>{number}. {name}</h2>
        <p>{description}</p>
      </div>
    </div>
  );
}

export default AnimalCard;