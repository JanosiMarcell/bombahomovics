import React from 'react';
import './App.css';
import Header from './Header';
import CardGrid from './CardGrid';
import { useState } from 'react';

function App() {
  const[bgcolor,setbgcolor]=useState("#FFF")
  return (
    <div className="App">
      <Header />
      <input type="color" onChange={function(event) {
        setbgcolor(event.target.value)
      }} />
      <CardGrid bgcolor={bgcolor}/>
    </div>
  );
}

export default App;