import React from 'react';
import { useState } from 'react';
import AnimalCard from './AnimalCard';
import './CardGrid.css';
import kep1 from './top1.png'
import kep2 from './top2.jpg'
import kep3 from './top3.jpg'
import kep4 from './top4.jpg'
import kep5 from './top5.jpg'
import kep6 from './top6.jpg'
import kep7 from './top7.jpg'

const animals = [
  { number: 10, name: "I can't breathe", image: kep1, description: 'Egy kedves és mókás állat.'},
  { number: 9, name: 'Berényi KFT', image: kep2, description: 'Nagyon intelligens.' },
  { number: 8, name: 'Kövér Laci', image: kep3,  description: 'Egyedülállóan ugrál.' },
  { number: 7, name: 'Ghost of Kyiv', image: kep4, description: 'A bölcsesség szimbóluma.' },
  { number: 6, name: 'Tigris', image: kep5, description: 'Erős és fenséges.' },
  { number: 5, name: 'Panda', image: kep6, description: 'Cuki és békés.' },
  { number: 4, name: 'Kutya', image: kep7, description: 'Az ember legjobb barátja.' },
  { number: 3, name: 'Macska', image: 'https://via.placeholder.com/150', description: 'Önálló és kedves.' },
  { number: 2, name: 'Orángután', image: 'https://via.placeholder.com/150', description: 'Nagyon hasonlít az emberre.' },
  { number: 1, name: 'Ló', image: 'https://via.placeholder.com/150', description: 'Erős és hűséges.' }
];

function CardGrid({bgcolor}) {
    
  return (
    <div className="card-grid">
      {animals.map(animal => (
        <AnimalCard 
          key={animal.number} 
          number={animal.number} 
          name={animal.name} 
          image={animal.image} 
          description={animal.description} 
          bgcolor={bgcolor}
        />
      ))}
    </div>
  );
}

export default CardGrid;