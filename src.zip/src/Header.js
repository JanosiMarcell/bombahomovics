import React from 'react';
import './Header.css';
import anyad from './headerimg.png'

function Header() {
  return (
    <header className="header">
      <img src={anyad} alt="Header Image" className="header-image" />
      <h1 className="header-title">Top 10 Kedvenc Állatom</h1>
    </header>
  );
}

export default Header;