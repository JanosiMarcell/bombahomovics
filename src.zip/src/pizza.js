//get
fetch("https://pizza.kando-dev.eu/Pizza")
.then(function(adatok) {
    return adatok.json();
})
.then(function(okadatok){
    console.log(okadatok);
    for (const adat of okadatok) {
        document.getElementById("container").innerHTML+=
        `<div class="card" style="width: 18rem;">
        <img src="${adat.kepURL}" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">${adat.name}</h5>
          <p class="card-text">Gluténmentes: ${adat.isGlutenFree == true ? "Nem":"Igen"}</p>
          <button onclick="deletedata(${adat.id})">Törlés</button>
        </div>
      </div>`
        
    }
})
//post

document.getElementById("post").onsubmit=function(event) {
    event.preventDefault()
    const adatok={
        id: Number(document.getElementsByTagName("input")[0].value),
        name:    document.getElementsByTagName("input")[1].value,
        isGlutenFree:    Number(document.getElementsByTagName("input")[2].checked),
        kepURL:     document.getElementsByTagName("input")[3].value,
        

        
     }
     fetch("https://pizza.kando-dev.eu/Pizza",{
        method: "POST",
        body: JSON.stringify(adatok),
        headers:{
            "Content-Type": "application/json"
        }
     })
     .then(function(){
        location.reload()
     })
    }


//put
//delete
function deletedata(id){
    if ((confirm("Biztos törlöd?"))) {
        fetch("https://pizza.kando-dev.eu/Pizza" + id,{
            method: "DELETE"
        })
        .then(function(){
            location.reload();
        })
        
    }

}
